const extensions = [
    // 扩展列表，使用一对英文引号（''或""均可）填写扩展文件夹名称，每一个扩展项目之间使用英文逗号（,）分隔
    // 语法指南：https://www.w3school.com.cn/js/js_arrays.asp

    // 'example'
];