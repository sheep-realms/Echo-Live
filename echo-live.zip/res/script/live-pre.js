let extensionManager = new ExtensionManager();
extensionManager.mixer = mixer;
extensionManager.launch(extensions);