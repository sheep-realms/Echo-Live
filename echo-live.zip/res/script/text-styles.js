// 未实装
const textStyles = [
    {
        name: 'color',
        style: {
            name: 'color'
        }
    }, {
        name: 'bold',
        class: {
            name: 'echo-text-bold'
        }
    }, {
        name: 'italic',
        class: {
            name: 'echo-text-italic'
        }
    }, {
        name: 'underline',
        class: {
            name: 'echo-text-underline'
        }
    }, {
        name: 'rock',
        class: {
            name: 'echo-text-rock-',
            insert_value: true
        }
    }, {
        name: 'style',
        style: {
            special: true
        }
    }
];