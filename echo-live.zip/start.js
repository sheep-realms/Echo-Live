echolive.send({
    username: "【？？？】",
    messages: [
        {
            message: [
                {
                    text: '"Every ordinary      day we experience may be a continuous miracle."',
                    style: { style: 'text-indent: -0.5em; display: block;' }
                }
            ]
        }
    ]
});